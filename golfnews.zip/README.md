# VGS-Itern
Login = OTP phone vào trang quản trị push notification
Thêm mới text notification vào bảng notification
Sửa hoặc xoá notification
Notification dạng text có phần ngày push,ngày tạo,người tạo và trạng thái đã push đi hay pendding hoặc lỗi.
Yêu cầu notification chỉ được sửa hoặc tạo  khi thời gian push cách thời gian hiện tại lớn hơn 2h.Nếu trong khoảng thời gian này chỉ có thể xoá hoặc disable notification

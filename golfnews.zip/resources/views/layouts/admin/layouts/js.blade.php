  <script src="{{asset('admin/js/core/jquery.min.js')}}"></script>
  <script src="{{asset('admin/js/core/popper.min.js')}}"></script>

  <script src="{{asset('admin/js/plugins/perfect-scrollbar.jquery.min.js')}}"></script>
  <!--  Google Maps Plugin    -->

  <!-- Chart JS -->
  <script src="{{asset('admin/js/plugins/chartjs.min.js')}}"></script>
  <!--  Notifications Plugin    -->
  <script src="{{asset('admin/js/plugins/bootstrap-notify.js')}}"></script>

  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="{{asset('admin/js/core/bootstrap.min.js')}}"></script>
  <!-- Control Center for Now Ui Dashboard: parallax effects, scripts for the example pages etc -->

  {{-- <script src="{{asset('admin/js/paper-dashboard.min.js')}}" type="text/javascript"></script> --}}

  <!-- Paper Dashboard DEMO methods, don't include it in your project! -->
  
{{--   <script src="{{asset('admin/demo/demo.js')}}"></script>
  <script>
    $(document).ready(function() {
      // Javascript method's body can be found in assets/assets-for-demo/js/demo.js
      demo.initChartsPages();
    });
  </script> --}}
 <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, shrink-to-fit=no' name='viewport' />
  <!--     Fonts and icons     -->
  <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700,200" rel="stylesheet" />
  <link href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet">
  <!-- CSS Files -->
  <link href="<?php echo e(asset('admin/css/bootstrap.min.css')); ?>" rel="stylesheet" />
  <link href="<?php echo e(asset('admin/css/css/bootstrap.min.css')); ?>" rel="stylesheet" />
  <link href="<?php echo e(asset('admin/css/paper-dashboard.css')); ?>" rel="stylesheet" />
  <!-- CSS Just for demo purpose, don't include it in your project -->
  <link href="<?php echo e(asset('admin/demo/demo.css')); ?>" rel="stylesheet" />
  <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" /><?php /**PATH E:\hoc laravel\golfnews\resources\views/layouts/admin/layouts/css.blade.php ENDPATH**/ ?>
 <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700,800,900" rel="stylesheet">

    <link rel="stylesheet" href="<?php echo e(asset('home/css/open-iconic-bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('home/css/animate.css')); ?>">
    
    <link rel="stylesheet" href="<?php echo e(asset('home/css/owl.carousel.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('home/css/owl.theme.default.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('home/css/magnific-popup.css')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('home/css/aos.css')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('home/css/ionicons.min.css')); ?>">
    
    <link rel="stylesheet" href="<?php echo e(asset('home/css/flaticon.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('home/css/icomoon.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('home/css/style.css')); ?>"><?php /**PATH E:\hoc laravel\add2\resources\views/layouts/home/layouts/css.blade.php ENDPATH**/ ?>
<script src="<?php echo e(asset('home/js/jquery.min.js')); ?>"></script>
  <script src="<?php echo e(asset('home/js/jquery-migrate-3.0.1.min.js')); ?>"></script>
  <script src="<?php echo e(asset('home/js/popper.min.js')); ?>"></script>
  <script src="<?php echo e(asset('home/js/bootstrap.min.js')); ?>"></script>
  <script src="<?php echo e(asset('home/js/jquery.easing.1.3.js')); ?>"></script>
  <script src="<?php echo e(asset('home/js/jquery.waypoints.min.js')); ?>"></script>
  <script src="<?php echo e(asset('home/js/jquery.stellar.min.js')); ?>"></script>
  <script src="<?php echo e(asset('home/js/owl.carousel.min.js')); ?>"></script>
  <script src="<?php echo e(asset('home/js/jquery.magnific-popup.min.js')); ?>"></script>
  <script src="<?php echo e(asset('home/js/aos.js')); ?>"></script>
  <script src="<?php echo e(asset('home/js/jquery.animateNumber.min.js')); ?>"></script>
  <script src="<?php echo e(asset('home/js/scrollax.min.js')); ?>"></script>
  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBVWaKrjvy3MaE7SQ74_uJiULgl1JY0H2s&sensor=false"></script>
  <script src="<?php echo e(asset('home/js/google-map.js')); ?>"></script>
  <script src="<?php echo e(asset('home/js/main.js')); ?>"></script><?php /**PATH E:\hoc laravel\add2\resources\views/layouts/home/layouts/js.blade.php ENDPATH**/ ?>
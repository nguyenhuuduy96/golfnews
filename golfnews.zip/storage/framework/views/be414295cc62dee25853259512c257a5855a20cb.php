<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8" />
  <link rel="apple-touch-icon" sizes="76x76" href="<?php echo e(asset('admin/img/apple-icon.png')); ?>">
  <link rel="icon" type="image/png" href="<?php echo e(asset('admin/img/favicon.png')); ?>">
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
  <title><?php echo $__env->yieldContent('title'); ?></title>
  <?php echo $__env->make('layouts.admin.layouts.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body class="">
  <div class="wrapper ">
    <?php echo $__env->make('layouts.admin.layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    <div class="main-panel">
      <!-- Navbar -->

     <?php echo $__env->make('layouts.admin.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <!-- End Navbar -->
      <div class="content">
        <?php echo $__env->yieldContent('content'); ?>
      </div>
     <?php echo $__env->make('layouts.admin.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
    </div>
  </div>
  <!--   Core JS Files   -->
<?php echo $__env->make('layouts.admin.layouts.js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->yieldContent('js'); ?>
</body>

</html>
<?php /**PATH E:\hoc laravel\golfnews\resources\views/main.blade.php ENDPATH**/ ?>